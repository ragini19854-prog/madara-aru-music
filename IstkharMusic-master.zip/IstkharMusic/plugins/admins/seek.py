from pyrogram import filters
from pyrogram.types import Message

from IstkharMusic import YouTube, app
from IstkharMusic.core.call import ISTKHAR
from IstkharMusic.misc import db
from IstkharMusic.utils import AdminRightsCheck, seconds_to_min
from IstkharMusic.utils.inline import close_markup
from config import BANNED_USERS


@app.on_message(
    filters.command(["seek", "cseek", "seekback", "cseekback"])
    & filters.group
    & ~BANNED_USERS
)
@AdminRightsCheck
async def seek_comm(cli, message: Message, _, chat_id):
    if len(message.command) == 1:
        return await message.reply_text(_["admin_20"])    
    query = message.text.split(None, 1)[1].strip()
    if not query.isnumeric():
        return await message.reply_text(_["admin_21"])
    duration_to_skip = int(query)
    playing = db.get(chat_id)
    if not playing:
        return await message.reply_text(_["queue_2"])
    duration_seconds = int(playing[0]["seconds"])
    if duration_seconds == 0:
        return await message.reply_text(_["admin_22"])
    file_path = playing[0]["file"]
    duration_played = int(playing[0]["played"])
    duration_total_str = playing[0]["dur"]
    is_seek_back = message.command[0][-2] == "c"
    if is_seek_back:
        seek_target = duration_played - duration_to_skip
        if seek_target <= 10:
             return await message.reply_text(
                text=_["admin_23"].format(seconds_to_min(duration_played), duration_total_str),
                reply_markup=close_markup(_),
            )      
        to_seek = seek_target + 1
    else:
        seek_target = duration_played + duration_to_skip
        remaining_time = duration_seconds - seek_target
        if remaining_time <= 10:
             return await message.reply_text(
                text=_["admin_23"].format(seconds_to_min(duration_played), duration_total_str),
                reply_markup=close_markup(_),
            )      
        to_seek = seek_target + 1
    mystic = await message.reply_text(_["admin_24"])
    if "vid_" in file_path:
        n, file_path = await YouTube.video(playing[0]["vidid"], True)
        if n == 0:
            return await message.reply_text(_["admin_22"])
    check_speed = (playing[0]).get("speed_path")
    if check_speed:
        file_path = check_speed
    if "index_" in file_path:
        file_path = playing[0]["vidid"]
    try:
        await ISTKHAR.seek_stream(
            chat_id,
            file_path,
            seconds_to_min(to_seek),
            duration_total_str,
            playing[0]["streamtype"],
        )
    except Exception:
        return await mystic.edit_text(_["admin_26"], reply_markup=close_markup(_))
    if is_seek_back:
        db[chat_id][0]["played"] -= duration_to_skip
    else:
        db[chat_id][0]["played"] += duration_to_skip
    await mystic.edit_text(
        text=_["admin_25"].format(seconds_to_min(to_seek), message.from_user.mention),
        reply_markup=close_markup(_),
    )